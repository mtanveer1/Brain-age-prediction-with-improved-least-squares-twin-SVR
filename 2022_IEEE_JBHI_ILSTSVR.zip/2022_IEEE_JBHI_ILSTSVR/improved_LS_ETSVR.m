function [PredictY,time]=improved_LS_ETSVR(TestX,Data,FunPara)
% Input:
%  TestX - Test Data matrix. Each row vector of fea is a data point.
%  DataTrain - stuct value in Matlab-----Training data.
%
%
%   FunPara - Struct value in Matlab
%       FunPara.p1: [0,inf] Paramter to tune the weight;
%       FunPara.p2: [0,inf] Paramter to tune the weight;
%       FunPara.p3: [0,inf] Paramter to tune the weight;
%       FunPara.p4: [0,inf] Paramter to tune the weight;
%       FunPara.p5: [0,inf] Paramter to tune the weight;
%       FunPara.p6: [0,inf] Paramter to tune the weight;
%
%       kerfPara: kernel parameters. See kernelfun.m;
%
% Output:
%     PredictY - Predict value of the TestX.
%
% Examples:
% load SincTN1.mat X Y TestX TestY
% DataTrain.X = X;
% DataTrain.Y = Y;

%           PredictY= ETSVR(TestX,DataTrain,FunPara);
%
% Reference: M.A. Ganaie, M. Tanveer, and Iman Beheshti. "Brain age prediction with improved least squares twin SVR." IEEE Journal of Biomedical and Health Informatics (2022).
%
%    Version 1.0 --Jun/2013
%
%    Written by M.A. Ganaie (phd1901141006@iiti.ac.in)
%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%


%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
% Initailization
%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
tic;
c1= FunPara.c1;
%c2= FunPara.p2;
c2=c1;
c3= FunPara.c3;
%c4= FunPara.p4;
c4=c3;
eps1 = FunPara.eps1;
%eps2 = FunPara.p6;
eps2=eps1;
kerfPara = FunPara.kerfPara;
DataTrain=[Data.X,Data.Y];
A=DataTrain(:,1:end-1);
Y=DataTrain(:,end);
%clear DataTrain
[samples, features]=size(A);
e=ones(samples,1);
kerfPara = FunPara.kerfPara;
if strcmp(kerfPara.type,'lin')
    AAt=A*A';
else
    %AAt=A*A';
    AAt=kernelfun(A,kerfPara);
end
Q=[AAt+c3*eye(size(AAt)),AAt;AAt,AAt+(c3/c1)*eye(size(AAt))];
E=ones(size(Q));
QE=Q+E;
linQ1=c3*[-Y',-(Y+(eps1*e))'];
eps=10^-4;
bestalpha1=LSSMO3(QE,eps,c3,linQ1);
clear Q

linQ2=c4*[Y',(Y-(eps2*e))'];
bestalpha2=LSSMO3(QE,eps,c3,linQ2);
time=toc;
%%
if strcmp(kerfPara.type,'lin')
    v1=-(1/c3)*[A',A';ones(1,2*size(A,1))]*bestalpha1;
    v2=-(1/c4)*[A',A';ones(1,2*size(A,1))]*bestalpha2;
else
    A=kernelfun(A,kerfPara);
    v1=-(1/c3)*[A',A';ones(1,2*size(A,1))]*bestalpha1;
    v2=-(1/c4)*[A',A';ones(1,2*size(A,1))]*bestalpha2;
end


e=ones(size(TestX,1),1);
m = size(v1,1);
if strcmp(kerfPara.type,'lin')
    Y1=TestX*v1(1:m-1)+v1(m)*e;
    Y2=TestX*v2(1:m-1)+v2(m)*e;
else
    H=kernelfun(TestX,kerfPara,DataTrain(:,1:end-1));
    Y1=H*v1(1:m-1)+v1(m)*e;
    Y2=H*v2(1:m-1)+v2(m)*e;
end
DarwY.Y1 = Y1 - eps1;
DarwY.Y2 = Y2 + eps1;
PredictY=0.5*(Y1+Y2);
end