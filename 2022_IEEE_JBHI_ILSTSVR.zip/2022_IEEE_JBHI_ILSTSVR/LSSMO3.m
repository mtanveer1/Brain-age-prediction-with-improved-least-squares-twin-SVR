function bestalpha = LSSMO3(Q,eps,c,v)
[no_row,m] = size(Q);
x = zeros(no_row,1); 
F=[];
D=[];

for i = 1:no_row
    Fi = -x'*Q(:,i)-c*v(i);
    Di=Fi*Fi/(2*Q(i,i));
    F(i) = Fi;
    D(i) = Di;
end
normF = norm(F);

iter=0;
while normF>eps*no_row && iter<500
    [Max,i]=max(D);
    t=F(i)/Q(i,i);
    x(i)=x(i)+t;  
    for i = 1:no_row
        Fi = -x'*Q(:,i)-c*v(i);
        Di=Fi*Fi/(2*Q(i,i));
        F(i) = Fi;
        D(i) = Di;
    end
    normF = norm(F);
end
bestx=x;
end