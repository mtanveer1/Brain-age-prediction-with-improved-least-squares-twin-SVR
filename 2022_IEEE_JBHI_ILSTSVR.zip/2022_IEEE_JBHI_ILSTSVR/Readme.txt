The code corresponds to the paper "M. A. Ganaie, M. Tanveer, and Iman Beheshti. "Brain age prediction with improved least squares twin SVR." IEEE Journal of Biomedical and Health Informatics (2022)."

If you are using our code, please give proper citation to the above given paper.

If there is any issue/bug in the code please write to phd1901141006@iiti.ac.in